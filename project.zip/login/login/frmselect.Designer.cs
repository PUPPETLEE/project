﻿namespace login
{
    partial class frmselect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.btnFullTime = new System.Windows.Forms.Button();
            this.btnPartTime = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnFullTime
            // 
            this.btnFullTime.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFullTime.Location = new System.Drawing.Point(48, 74);
            this.btnFullTime.Name = "btnFullTime";
            this.btnFullTime.Size = new System.Drawing.Size(163, 35);
            this.btnFullTime.TabIndex = 1;
            this.btnFullTime.Text = "full-time employe";
            this.btnFullTime.UseVisualStyleBackColor = true;
            this.btnFullTime.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnPartTime
            // 
            this.btnPartTime.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPartTime.Location = new System.Drawing.Point(247, 74);
            this.btnPartTime.Name = "btnPartTime";
            this.btnPartTime.Size = new System.Drawing.Size(163, 35);
            this.btnPartTime.TabIndex = 2;
            this.btnPartTime.Text = "part-time employee";
            this.btnPartTime.UseVisualStyleBackColor = true;
            this.btnPartTime.Click += new System.EventHandler(this.button1_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(-1, -3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(41, 33);
            this.button1.TabIndex = 3;
            this.button1.Text = "<";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // frmselect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 175);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnPartTime);
            this.Controls.Add(this.btnFullTime);
            this.Name = "frmselect";
            this.Text = "frmselect";
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button btnFullTime;
        private System.Windows.Forms.Button btnPartTime;
        private System.Windows.Forms.Button button1;
    }
}