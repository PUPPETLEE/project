﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//here
using System.Data.SqlClient;

namespace login
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\miranjo\\Documents\\table.mdf;Integrated Security=True;Connect Timeout=30");

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            //Work here
            frmCreateAccount frmCreateAccount = new frmCreateAccount();
            frmCreateAccount.ShowDialog();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username, userPassword;
            try
            {
                string querry = "SELECT * FROM data Where username='" + txtUsername.Text+"' and Password ='"+txtPassword.Text+"'";
                SqlDataAdapter sda = new SqlDataAdapter(querry,con);
                DataTable dt = new DataTable();
                sda.Fill(dt);


                /*SqlDataAdapter sda1 = new SqlDataAdapter("SELECT * FROM dataEmployee Where username='" + txtUsername.Text + "' and Password ='" + txtPassword.Text + "'", con);
                DataTable dt1 = new DataTable();
                sda1.Fill(dt1);*/

                    if (dt.Rows.Count > 0)
                    {
                        username = txtUsername.Text;
                        userPassword = txtPassword.Text;
                        //form page needed to be load
                        frmHrManager manager = new frmHrManager();
                        manager.Show();
                        this.Hide();
                    }
                
            
                else
                {
                    
                        MessageBox.Show("Please check your password and account name and try again.");
                    
                }
                
            
            }
            catch
            {
                MessageBox.Show("error");
            }finally
            {
                con.Close();
            }



            /* Use double slash 
            SqlDataAdapter sda = new SqlDataAdapter("SELECT COUNT * FROM data where username='" + txtUsername+"' and Password ='"+txtPassword+"'",con);
            DataTable dt = new DataTable(); 
            sda.Fill(dt);
                if (dt.Rows.Count >0)
                {
                    this.Hide();
                    sign_up sign_Up = new sign_up();
                    sign_Up.Show();


                }
                else
                {
                    MessageBox.Show("Please check your password and account name and try again.");
                }
              */
                
            

        }

        private void radHrManager_CheckedChanged(object sender, EventArgs e)
        {
                                
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            frmselect select  = new frmselect();
            select.Show();
            this.Hide();

        }
    }
}
